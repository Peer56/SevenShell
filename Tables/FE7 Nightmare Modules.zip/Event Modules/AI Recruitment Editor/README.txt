Editor by Fire Blazer
Info thanks to Nintenlord

This editor allows you to make an NPC or enemy character controlled by the AI go to a unit and talk to them on their own. The first part specifies the character to initiate the convo and the second specifies the speaker and who they are speaking to. There must also be a conversation event for them in the chapter's events.

The AI set for the person who automatically goes to talk to a unit must be 06 0B 0A 00 for this to work.

Once again, thanks to Nintenlord for the information.